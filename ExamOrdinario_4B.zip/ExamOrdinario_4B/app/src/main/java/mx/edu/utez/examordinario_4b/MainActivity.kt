package mx.edu.utez.examordinario_4b

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import mx.edu.utez.examordinario_4b.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

    }

    //aqui es p ara que me implemente mi menu  en la pagina principall
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.estaciones -> {
                val intent = Intent (this@MainActivity, MainActivity2:: class.java)
                startActivity(intent)
            }

            R.id.data -> {

            }
            R.id.register-> {
                val intent = Intent (this@MainActivity, MainActivity3:: class.java)
                startActivity(intent)
            }
        }
        return true
    }
}