package mx.edu.utez.examordinario_4b

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mx.edu.utez.examordinario_4b.databinding.ActivityMain2Binding
import mx.edu.utez.examordinario_4b.databinding.ActivityMain3Binding

class MainActivity3 : AppCompatActivity() {
    lateinit var binding: ActivityMain3Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMain3Binding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
    }
}