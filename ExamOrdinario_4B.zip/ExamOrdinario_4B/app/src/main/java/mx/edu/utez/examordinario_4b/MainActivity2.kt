package mx.edu.utez.examordinario_4b

import android.R
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.renderscript.ScriptGroup.Binding
import android.widget.ArrayAdapter
import mx.edu.utez.examordinario_4b.databinding.ActivityMain2Binding
import mx.edu.utez.examordinario_4b.databinding.ActivityMainBinding

class MainActivity2 : AppCompatActivity() {
    lateinit var binding: ActivityMain2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMain2Binding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
//spinner
        val datos = listOf("","Primavera", "Verano", "Otoño", "Invierno")
        //1.contexto, 2. estilo(layout), 3.datos
        val adapatador = ArrayAdapter(this@MainActivity2,
            R.layout.simple_list_item_1, datos
        )
        binding.sp1.adapter = adapatador
        binding.sp1.adapter = adapatador




    }
}